<template>
  <div class="min-h-screen w-full overflow-hidden">
    <NuxtPage/>
  </div>
</template>


<template>
  <div class=" w-full overflow-hidden">
    <NuxtPage/>
  </div>
</template>


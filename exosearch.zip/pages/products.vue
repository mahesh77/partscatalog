<script setup>

    import { ref, computed, onMounted } from 'vue';
    import { useRoute, useRouter } from 'nuxt/app';

    // import 'primevue/datatable/datatable.css';
    // import 'primevue/paginator/paginator.css';


  //  const { products, error } = useProducts();
  const { data, error } = await useFetch('/api/all_products', {
  lazy: false,
  server: true
})

const products = computed(() => data.value?.products || [])
    const productTypes = useProductTypes(products);
    // const productApplications = useProductApplications(products);

    const route = useRoute();
    const router = useRouter();

    // Store selected filters in a reactive state
    const selectedType = ref();
    const selectedParametricFeatures = ref([]);
    const selectedApplications = ref([]);
    const selectedCountries = ref([])


    // When the page loads, set the initial filter from the query

    onMounted(() => {
        selectedType.value = route.query.type || productTypes.value?.[0];
    });

    router.replace({ path: '/products' });


    watch(error, (err) => {
        if (err) {
            console.error('Error loading products:', err);
        }
    });

    const typeFilteredProducts = computed(() => {
        if (products.value) {
		//  if (searchQuery.value) return products.value // skip filtering when search is active

            return products.value.filter(product => product.type === selectedType.value)
        }
    });

    function labelFromFeatureKey(key) {
        return key
            .replace(/^ft_/, '')       // remove "ft_" prefix
            .replace(/_/g, ' ')        // replace remaining underscores with spaces
            .replace(/^\w/, c => c.toUpperCase()); // capitalize first letter
    }
    

    const { transform } = useTransformProducts();
    const transformedData = computed(() => {
        return transform(typeFilteredProducts.value);
    });


    const finalFilteredProducts = computed(() => {
        if (!transformedData) return []
            return transformedData.value.filter(product => {
            const matchesApplications =
                selectedApplications.value.length === 0 ||
                selectedApplications.value.some(app =>
                product.applications?.includes(app)
            )

            const matchesCountry =
            selectedCountries.value.length === 0 ||
            selectedCountries.value.includes(product.country_of_origin)

            return matchesApplications && matchesCountry
        })
    })

    const parametricFeatures = computed(() => {

        const first = transformedData.value?.[0];
        if (!first) return [];
            return Object.keys(first).filter(key => key.startsWith('ft_'));
    });

    function selectDefaultParametricFeatures() {
        selectedParametricFeatures.value = parametricFeatures.value.slice(0, 5);
    }

    onMounted(() => {
        selectDefaultParametricFeatures();
    });

    watch(selectedType, () => {
        selectDefaultParametricFeatures();
    })

    const uniqueApplications = computed(() => {
        const appSet = new Set()
		console.log(transformedData)
		console.log(transformedData.value)
        transformedData.value.forEach(product => {
            product.applications?.forEach(app => appSet.add(app))
        })

        return Array.from(appSet)
    })

    const uniqueCountries = computed(() => {
        const countrySet = new Set()

        transformedData.value.forEach(product => {
            if (product.country_of_origin) {
            countrySet.add(product.country_of_origin)
            }
        })

        return Array.from(countrySet)
    })

    const visible = ref(false);
// fuzzy search bar code
import Fuse from 'fuse.js'

// Search input
const search = ref('')

const matchedProducts = computed(() => {
  const term = search.value.trim().toLowerCase();
  if (!term) return finalFilteredProducts.value;

  return finalFilteredProducts.value.filter(product => {
    return (
      (product.product?.toLowerCase().includes(term)) ||
      (product.sku?.toLowerCase().includes(term)) ||
      (product.description?.toLowerCase().includes(term))
    );
  });
});

// toggle refine result section

const showFilters = ref(false);

function toggleApplication(app) {
  const index = selectedApplications.value.indexOf(app);
  if (index > -1) {
    selectedApplications.value.splice(index, 1); // remove
  } else {
    selectedApplications.value.push(app); // add
  }
}

function toggleParametric(feature) {
  const index = selectedParametricFeatures.value.indexOf(feature);
  if (index === -1) {
    selectedParametricFeatures.value.push(feature);
  } else {
    selectedParametricFeatures.value.splice(index, 1);
  }
}

</script>

<template class="!bg-white">
    <section class="w-full max-w-7xl">
		 <hgroup class="w-full p-4 sticky  top-0 left-0 main-background">
        	<span class="large text-white text-[26px] left-[39px] ">exo<span class="exo font-bold text-[30px]">search</span></span>
		   <!-- <p>The technical search engine for industry.</p>-->
		   <div class=" mt-4 float-right text-white">
			<ul class="flex flex-wrap gap-2 ">
			  <li class="inline-block"><a href="#">All products</a></li>
			  <li class="inline-block"><a href="#">About</a></li>
			  <li class="inline-block"><a href="#">Vendor sign-in</a></li>
			</ul>
		   </div>
		</hgroup>
		</section>
		<section class="relative mt-[3rem] left-[39px]">
        <h3 class="font-bold text-[24px] mb-[1.5rem]">Explore products</h3>
        <form>
            <template v-if="products">
                <fieldset>
                    <legend class="font-semibold">Showing components for</legend>
                    <div class="flex flex-wrap gap-3 mt-5">
					  <div v-for="productType in productTypes" :key="productType">
						<!-- hidden radio -->
						<input
						  type="radio"
						  :id="productType"
						  name="productType"
						  :value="productType"
						  v-model="selectedType"
						  class="hidden peer"
						/>
					
						<!-- custom label -->
						<label
						  :for="productType"
						  class="cursor-pointer text-[#1728e5] bg-[#e2eafa] border-0 no-underline text-[17px]] pr-[11px] pl-[8px] 
								 flex items-center transition"
						>
						  <!-- icon (shows when selected) -->
						  <i class="fas fa-check text-sm" v-if="selectedType === productType"></i>
						  {{ productType }}
						</label>
					  </div>
					</div>

                </fieldset>
				<Button @click="visible = true" label="Refine results" class="bg-[#1728e5]"></Button>
                <Drawer v-model:visible="visible" header="Refine results">
				
              <!-- <div class="flex items-center gap-2 mb-4">
							   <svg  @click="showFilters = !showFilters" width="16" height="16" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg" class="icon-sm text-token-text-tertiary"><path d="M12.1338 5.94433C12.3919 5.77382 12.7434 5.80202 12.9707 6.02929C13.1979 6.25656 13.2261 6.60807 13.0556 6.8662L12.9707 6.9707L8.47067 11.4707C8.21097 11.7304 7.78896 11.7304 7.52926 11.4707L3.02926 6.9707L2.9443 6.8662C2.77379 6.60807 2.80199 6.25656 3.02926 6.02929C3.25653 5.80202 3.60804 5.77382 3.86617 5.94433L3.97067 6.02929L7.99996 10.0586L12.0293 6.02929L12.1338 5.94433Z"></path></svg>
				  <span class="font-semibold text-lg">Refine Results</span>
				 
				</div>-->
				

                   <div v-if="uniqueApplications.length">
					  <p class="font-medium mb-1">Applications</p>
					  <div class="flex flex-wrap gap-2">
						<button type="button"
						  v-for="app in uniqueApplications"
						  :key="app"
						  @click="toggleApplication(app)"
						  :class="[
							'flex items-center gap-2 px-3 py-1 border rounded-full text-sm transition',
							selectedApplications.includes(app)
							  ? 'bg-blue-600 text-white border-blue-600'
							  : 'bg-white text-gray-700 border-gray-300 hover:bg-blue-50'
						  ]"
						>
						  <span>{{ app }}</span>&nbsp;&nbsp;
						  <i v-if="!selectedApplications.includes(app)" class="fas fa-plus text-xs"></i>
						  <i v-else class="fas fa-check text-xs"></i>
						</button>
					  </div>
					</div>
                    <fieldset v-if="uniqueCountries.length > 1">
                        <legend>Refine by countries of origin</legend>
                        <div v-for="uniqueCountry in uniqueCountries">
                            <input type="checkbox" :id="uniqueCountry" :name="uniqueCountry" :value="uniqueCountry" v-model="selectedCountries" />
                            <label :for="uniqueCountry">{{ uniqueCountry }}</label>
                        </div>
                    </fieldset>
                    <fieldset>
                        <legend>Show/hide parametric columns</legend>
                         <div class="flex flex-wrap gap-2">
						<button
						  type="button"
						  v-for="parametricFeature in parametricFeatures"
						  :key="parametricFeature"
						  @click="toggleParametric(parametricFeature)"
						  :class="[
							'flex items-center gap-2 px-3 py-1 border rounded-full text-sm transition',
							selectedParametricFeatures.includes(parametricFeature)
							  ? 'bg-blue-600 text-white border-blue-600'
							  : 'bg-white text-gray-700 border-gray-300 hover:bg-blue-50'
						  ]"
						>
						  <span>{{ labelFromFeatureKey(parametricFeature) }}</span> &nbsp;&nbsp;
						  <i v-if="!selectedParametricFeatures.includes(parametricFeature)" class="fas fa-plus text-xs">+</i>
						  <i v-else class="fas fa-check text-xs">x</i>
						</button>
					  </div>
                    </fieldset>
					
					<input
					  v-model="search"
					  placeholder="Search products..."
					  class="border px-4 py-2 rounded mb-4 w-full"
					/>
				
               </Drawer>
            </template>
        </form>
        <main>
            <DataTable
                class="my-table w-full"
                columnResizeMode="expand"
                v-if="products"
               :value="matchedProducts"
            >
                <Column sortable key="product" field="product" header="Product"/>
                <Column sortable  key="applications" field="applications" header="Applications">
                    <template #body="{ data }">
                        <div class="tags-cell">
                            <Tag v-for="(application, index) in data.applications" :key="index" :value="application"></Tag>
                        </div>
                    </template>
                </Column>
                <Column sortable key="country_of_origin" field="country_of_origin" header="Country of origin" />
                <template v-for="selectedParametricFeature in selectedParametricFeatures">
                    <Column sortable :field="selectedParametricFeature" :header="labelFromFeatureKey(selectedParametricFeature)" />
                </template>
				
            </DataTable>
        </main>
    </section>
</template>

<style scoped>

h1 {
    grid-column: 1 / span 12;
    grid-row: 1;
}

form {
    grid-column: 1 / span 12;
    grid-row: 2;
    display: flex;
    flex-direction: column;
    gap: 12px;
    align-items: start;
}

main {
    grid-column: 1 / span 12;
    grid-row: 3;
}

.cards-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.my-table :deep(.p-datatable-table) {
  table-layout: auto !important;
  width: auto;
  white-space: nowrap;
  td, th {
    padding: 4px 12px 4px 12px;
  }
}

.tags-cell {
    display: flex;
    gap: 2px;
}

</style>